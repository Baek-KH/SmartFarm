package com.smartFarm.mes.controller.pip;

import java.util.ArrayList;
import java.util.List;
import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;


import com.smartFarm.mes.dao.pip.PipDAO;
import com.smartFarm.mes.vo.pip.PipVO;


@Controller
@SessionAttributes("pip")
public class PipController {
	
	// 검색조건설정
	@ModelAttribute("conditionMap")
	public Map<String, String> searchConditionMap(){
		Map<String,	String> conditionMap = new HashMap<>();
		conditionMap.put("작물번호", "PIP_NO");
		conditionMap.put("작물이름", "PIP_NAME");
		
		return conditionMap;
		
	}
	
	@RequestMapping(value = "/getPipList.do")
	public String getPipList(
			@RequestParam(value="searchCondition", defaultValue="pip_name", required=false) String condition,
			
			PipVO vo, PipDAO pipDAO, Model model) {

		System.out.println("> 1컨트롤");
		
		
		model.addAttribute("PipList", pipDAO.getPipList(vo));
		return "pipList.jsp";
	}
	
	@RequestMapping("/getPip.do") 
	public String getPip(PipVO vo, PipDAO pipDAO, Model model) {		
		System.out.println("> 2컨트롤");
		
		model.addAttribute("pip", pipDAO.getPip(vo));
		return "getPip.jsp";
	}

	@RequestMapping("/updatePip.do") 
	public String updatePip(@ModelAttribute("pip") PipVO vo, PipDAO pipDAO) {
		
		System.out.println("> 3컨트롤");
	   
		pipDAO.updatePip(vo);
		return "getPipList";
	}
	
	@RequestMapping("/insertPip.do") 
	public String insertPip(PipVO vo, PipDAO pipDAO) {
		
		System.out.println("> 4컨트롤");
		
		pipDAO.insertPip(vo);
		return "getPipList";
	}
	
	@RequestMapping("/deletePip.do") 
	public String deletePip(PipVO vo, PipDAO pipDAO) {
		
		System.out.println("> 5컨트롤");
		
		pipDAO.deletePip(vo);
		return "getPipList.do";
	}	
}